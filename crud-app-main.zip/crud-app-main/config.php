<?php

$conn = mysqli_connect("localhost","ryhab","ryhab","crud") or die("Connection Failed");

?>

